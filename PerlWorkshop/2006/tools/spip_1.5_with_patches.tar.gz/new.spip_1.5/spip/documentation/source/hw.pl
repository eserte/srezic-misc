{{{ORANGE}}}#!/usr/bin/perl
{{{RED}}}use strict{{{OFF}}};
{{{RED}}}use warnings{{{OFF}}};

{{{BLUE}}}print {{{GREEN}}}"{{{OLIVE}}}Hello World!{{{RED}}}\n{{{GREEN}}}"{{{OFF}}};
