package DevTools;

use strict;
use warnings;


#------------------------------------------------------------------------------
# Von Exporter erben:
#------------------------------------------------------------------------------
use base qw/Exporter/;
our @EXPORT_OK = qw/taupu get_version wc_l/;


sub get_version ($) {
    #--------------------------------------------------------------------------
    # sub          : g e t _ v e r s i o n
    #--------------------------------------------------------------------------
    # Autor        : Christian D�hl
    # Aufgabe      : Version und Datum ermitteln.
    # Parameter    : Datei aus der ermittelt werden soll.
    # R�ckgabewert : (version, version_datum)
    #--------------------------------------------------------------------------
    # 0.0.1 - ??.??.200? - CD - Erstellt
    # 0.0.2 - 24.06.2005 - CD - An spip angepasst.
    #--------------------------------------------------------------------------

    my ($file) = @_;
    my @ret;

    open (IN, $file) or die "Kann '$file' nicht oeffnen: $!";
    while (<IN>) {
        if (/VERSION\s*=>\s*'([\d.]+\S*)'/) {
            push @ret, $1;
        }
        if (/VERSIONDATE\s*=>\s*'([-\d.]+)'/) {
            push @ret, $1;
            last
        }
    }
    close IN or die "Kann '$file' nicht schliessen: $!";

    return @ret;
} # sub DevTools::get_version


sub taupu ($) {
    #--------------------------------------------------------------------------
    # sub          : t a u p u
    #--------------------------------------------------------------------------
    # Autor        : Christian D�hl
    # Aufgabe      : Zahlen mit Tausendertrenner (".") ausgeben und Komma als
    #                Dezimaltrenner verwenden.
    #                (Kopiert aus dem Perl-Cook-Book und angepasst.)
    # Parameter    : Auszugebende Zahl
    # R�ckgabewert : Zahl mit Punkten
    #--------------------------------------------------------------------------
    # 0.0.1 - 10.12.2002 - CD - Erstellt
    #--------------------------------------------------------------------------

    my $text = reverse $_[0];
    $text =~ s:\.:,:g; # deutsches Komma als Dezimaltrenner
    $text =~ s/(\d\d\d)(?=\d)(?!\d*,)/$1./g;
    return scalar reverse $text;
} # sub DevTools::taupu


sub wc_l {
    #--------------------------------------------------------------------------
    # sub          : w c _ l
    #--------------------------------------------------------------------------
    # Autor        : Christian D�hl
    # Aufgabe      : Anzahl Zeilen der Datei ermitteln.
    # Parameter    : Datei aus der ermittelt werden soll.
    # R�ckgabewert : Anzahl Zeilen.
    #--------------------------------------------------------------------------
    # 0.0.1 - ??.??.200? - CD - Erstellt
    #--------------------------------------------------------------------------

    my $file = shift;

    open (IN, $file) or die "Kann '$file' nicht oeffnen: $!";
    while (<IN>) {}
    my $ret = $.;
    close IN or die "Kann '$file' nicht schliessen: $!";

    return $ret;

} # sub DevTools::wc_l


1;
